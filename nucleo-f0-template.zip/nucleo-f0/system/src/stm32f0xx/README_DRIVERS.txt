This folder is a placeholder where to add vendor provided source files
from the peripheral drivers library.

Study the vendor drivers library and identify the drivers source files.
Copy the files you need in your project to this folder.

Be sure you include the corresponding header files in the include folder.